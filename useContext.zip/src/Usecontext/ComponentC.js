import React, { useContext } from "react";
import { UserContext } from "./UserContext";
let ComponentC = () => {
  let Userdata = useContext(UserContext);
  return (
    <React.Fragment>
      <div className="card">
        <div className="card-body bg-info text-white">
          <p> ComponentC</p>
          <small>{JSON.stringify(Userdata)}</small>
        </div>
      </div>
    </React.Fragment>
  );
};

export default ComponentC;

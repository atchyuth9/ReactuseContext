import React from "react";
import ComponentB from "./ComponentB";
let ComponentA = () => {
  return (
    <React.Fragment>
      <div className="card">
        <div className="card-body bg-success text-white">
          <p> ComponentA</p>
          <ComponentB />
        </div>
      </div>
    </React.Fragment>
  );
};

export default ComponentA;

import React from "react";
import { createContext, useContext } from "react";
export const UserContext = React.createContext({});

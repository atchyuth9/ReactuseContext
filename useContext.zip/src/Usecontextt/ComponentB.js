import React from "react";
import ComponentC from "./ComponentC";
let ComponentB = () => {
  return (
    <React.Fragment>
      <div className="card">
        <div className="card-body bg-dark text-white">
          <p> ComponentB</p>
          <ComponentC />
        </div>
      </div>
    </React.Fragment>
  );
};

export default ComponentB;

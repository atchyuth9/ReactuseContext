import React, { useContext } from "react";
import { AppContext } from "./AppContext";
import { UserContext } from "./UserContext";
let ComponentC = () => {
  let userdata = useContext(UserContext);
  let appinfo = useContext(AppContext);
  return (
    <React.Fragment>
      <div className="card">
        <div className="card-body bg-info text-white">
          <p> ComponentC</p>
          <small>{JSON.stringify(userdata)}</small>
          <br />
          <small>{JSON.stringify(appinfo)}</small>
        </div>
      </div>
    </React.Fragment>
  );
};

export default ComponentC;

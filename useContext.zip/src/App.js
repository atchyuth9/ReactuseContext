import React, { useState, createContext, useContext } from "react";
import "./styles.css";
import ComponentA from "./Usecontextt/ComponentA";
import { UserContext } from "./Usecontextt/UserContext";
import { AppContext } from "./Usecontextt/AppContext";

let App = () => {
  let [UserData, setUserdata] = useState({
    Name: "achyu",
    CompanyName: "Virtusa"
  });
  let [appInfo, setappInfo] = useState({
    AppName: "Instagram",
    Version: "2.5.4"
  });
  return (
    <React.Fragment>
      <div className="container mt-3">
        <div className="row">
          <div className="col">
            <div className="card">
              <div className="card-body bg-danger text-white">
                <p>AppComponent</p>
                <small>{JSON.stringify(UserData)}</small>
                <br />
                <small>{JSON.stringify(appInfo)}</small>
                <UserContext.Provider value={UserData}>
                  <AppContext.Provider value={appInfo}>
                    <ComponentA />
                  </AppContext.Provider>
                </UserContext.Provider>
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default App;
